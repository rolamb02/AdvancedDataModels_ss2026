#!/bin/bash
# =============================================================
# TRIPLESTORE DEMO – Ausführungs-Script
# Gruppe 2: Semantic Triple Stores / RDF + SPARQL
#
# Voraussetzung: Oxigraph läuft (docker-compose up -d)
# Benutzung:     bash run_demo.sh
# =============================================================

ENDPOINT="http://localhost:7878"
QUERY_DIR="./queries"
DATA_DIR="./data"

# Farben für Terminal-Output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Hilfsfunktion: auf Enter warten
pause() {
    echo ""
    echo -e "${YELLOW}▶ Enter drücken für den nächsten Schritt...${NC}"
    read -r
    echo ""
}

# Hilfsfunktion: SPARQL-Query ausführen und JSON formatieren
run_query() {
    local file=$1
    local query
    query=$(cat "$file")
    curl -s -G "$ENDPOINT/query" \
        --data-urlencode "query=$query" \
        -H "Accept: application/sparql-results+json" \
        | python3 -c "
import sys, json
data = json.load(sys.stdin)
vars = data['head']['vars']
bindings = data['results']['bindings']
print(f'  Spalten: {vars}')
print(f'  Ergebnisse: {len(bindings)}')
print()
for b in bindings:
    row = []
    for v in vars:
        val = b.get(v, {}).get('value', '-')
        # URI kürzen für bessere Lesbarkeit
        if val.startswith('http://example.org/uni/'):
            val = 'uni:' + val[len('http://example.org/uni/'):]
        elif val.startswith('http://www.w3.org/'):
            val = 'rdfs:...'
        row.append(f'{v}={val}')
    print('  → ' + ' | '.join(row))
"
}

# =============================================================
echo ""
echo -e "${BOLD}=============================================================${NC}"
echo -e "${BOLD}  TRIPLESTORE DEMO – RDF + SPARQL${NC}"
echo -e "${BOLD}  Gruppe 2 | Universität Stuttgart${NC}"
echo -e "${BOLD}=============================================================${NC}"
echo ""

# =============================================================
echo -e "${BLUE}[SCHRITT 1] Verbindung zu Oxigraph prüfen${NC}"
# =============================================================
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$ENDPOINT/query?query=SELECT+%2A+WHERE+%7B%7D+LIMIT+1")
if [ "$STATUS" = "200" ]; then
    echo -e "  ${GREEN}✓ Oxigraph läuft auf $ENDPOINT${NC}"
else
    echo -e "  ${RED}✗ Oxigraph nicht erreichbar. Bitte zuerst starten:${NC}"
    echo -e "  ${YELLOW}  docker-compose up -d${NC}"
    exit 1
fi
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 2] Daten laden${NC}"
# =============================================================
echo "  Lade universitaeten.ttl in den Triplestore..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
    -X POST "$ENDPOINT/store" \
    -H "Content-Type: text/turtle" \
    --data-binary @"$DATA_DIR/universitaeten.ttl")

if [ "$HTTP_CODE" = "204" ] || [ "$HTTP_CODE" = "200" ]; then
    echo -e "  ${GREEN}✓ Daten erfolgreich geladen (HTTP $HTTP_CODE)${NC}"
else
    echo -e "  ${RED}✗ Fehler beim Laden (HTTP $HTTP_CODE)${NC}"
    exit 1
fi
echo ""
echo "  Was wurde geladen?"
echo "  • 1 Ontologie (Klassen-Hierarchie: Person → AcademicPerson → Professor/Student)"
echo "  • 4 Städte (Stuttgart, Karlsruhe, München, Berlin)"
echo "  • 4 Universitäten (UniStuttgart, KIT, TUM, FU Berlin)"
echo "  • 3 Professoren + 4 Studenten"
echo ""
echo -e "  ${YELLOW}→ Web-UI: $ENDPOINT (SPARQL Editor direkt im Browser)${NC}"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 3] Query 1 – Alle Universitäten${NC}"
echo -e "${BOLD}Zeigt: PREFIX, SELECT, WHERE, einfache Variable${NC}"
# =============================================================
echo ""
cat "$QUERY_DIR/01_alle_universitaeten.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/01_alle_universitaeten.sparql"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 4] Query 2 – Unis in Baden-Württemberg${NC}"
echo -e "${BOLD}Zeigt: Mehrere Triple-Muster kombinieren (kein JOIN-Keyword nötig!)${NC}"
# =============================================================
echo ""
cat "$QUERY_DIR/02_unis_in_bw.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/02_unis_in_bw.sparql"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 5] Query 3 – Studenten an der Uni Stuttgart${NC}"
echo -e "${BOLD}Zeigt: Konkreter URI als Filter + warum der Variablenname egal ist${NC}"
# =============================================================
echo ""
cat "$QUERY_DIR/03_studenten_uni_stuttgart.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/03_studenten_uni_stuttgart.sparql"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 6] Query 4 – OHNE Inferencing: Alle Personen${NC}"
echo -e "${BOLD}!!! AHA-MOMENT VORBEREITUNG: Was kommt raus? ${NC}"
# =============================================================
echo ""
echo "  Frage ans Publikum: Wie viele Ergebnisse erwartet ihr?"
echo "  (7 Personen im Datensatz: 3 Professoren + 4 Studenten)"
echo ""
cat "$QUERY_DIR/04_personen_OHNE_inferenz.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/04_personen_OHNE_inferenz.sparql"
echo ""
echo -e "  ${YELLOW}→ 0 Ergebnisse! Niemand ist explizit als uni:Person eingetragen.${NC}"
echo -e "  ${YELLOW}→ Der Store findet genau das, was explizit drin steht – nicht mehr.${NC}"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 7] Query 5 – MIT Inferencing: Alle Personen${NC}"
echo -e "${BOLD}!!! AHA-MOMENT: rdfs:subClassOf* traversiert die Klassen-Hierarchie${NC}"
# =============================================================
echo ""
echo "  Lösung: Property Path rdfs:subClassOf*"
echo "  Das * bedeutet: null oder mehr Schritte entlang rdfs:subClassOf"
echo "  Professor → AcademicPerson → Person ✓ (2 Schritte)"
echo "  Student   → AcademicPerson → Person ✓ (2 Schritte)"
echo ""
cat "$QUERY_DIR/05_personen_MIT_inferenz.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/05_personen_MIT_inferenz.sparql"
echo ""
echo -e "  ${GREEN}→ Alle 7 Personen! Obwohl niemand explizit als uni:Person eingetragen ist.${NC}"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 8] Query 6 – COUNT: Personen pro Universität${NC}"
echo -e "${BOLD}Zeigt: Aggregation (identisch zu SQL COUNT + GROUP BY)${NC}"
# =============================================================
echo ""
cat "$QUERY_DIR/06_count_pro_uni.sparql" | grep -v "^#" | sed 's/^/  /'
echo ""
echo -e "${GREEN}Ergebnis:${NC}"
run_query "$QUERY_DIR/06_count_pro_uni.sparql"
pause

# =============================================================
echo -e "${BLUE}[SCHRITT 9 – OPTIONAL] Query 7 – Federated Query gegen DBpedia${NC}"
echo -e "${BOLD}Zeigt: Warum globale URIs so mächtig sind – zwei Stores, eine Anfrage${NC}"
# =============================================================
echo ""
echo -e "  ${YELLOW}Hinweis: Braucht Internetzugang. DBpedia kann langsam sein (~5s).${NC}"
echo -e "  ${YELLOW}Bei Verbindungsproblemen: Screenshot als Fallback zeigen.${NC}"
echo ""
echo "  Ausführen? (j/n)"
read -r answer
if [ "$answer" = "j" ] || [ "$answer" = "J" ]; then
    cat "$QUERY_DIR/07_federated_dbpedia.sparql" | grep -v "^#" | sed 's/^/  /'
    echo ""
    echo -e "${GREEN}Ergebnis (kann einige Sekunden dauern):${NC}"
    run_query "$QUERY_DIR/07_federated_dbpedia.sparql"
else
    echo "  → Übersprungen."
fi

# =============================================================
echo ""
echo -e "${BOLD}=============================================================${NC}"
echo -e "${BOLD}  DEMO ABGESCHLOSSEN${NC}"
echo -e "${BOLD}=============================================================${NC}"
echo ""
echo "  Web-UI für eigene Queries: $ENDPOINT"
echo "  Nächster Schritt: Interaktive Übung (Query Challenge)"
echo ""
